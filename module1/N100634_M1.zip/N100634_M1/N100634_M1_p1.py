#Count the number of words in a given string.  

a=raw_input("ENTER A STRING\n")
b=a.split()                                                                                        #splitting the string
print "THE NO OF WORDS IN  STRING IS",len(b)
